# Arithmetic-Exam-Application
 a easy python project that implements python core topics from hyperskill
